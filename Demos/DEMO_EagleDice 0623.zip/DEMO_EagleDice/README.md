# DEMO - 地图大富翁（骰子系统）

本目录下为 UI Parts 目录下的 骰子系统 插件的范例工程。

## 注意

由于老鹰的懒惰，工程中所使用的插件版本可能并不是最新版，请自己比对。

## 素材来源

Graphics/System 目录下的 Window.png 文件来自于 [葱式解谜用简易菜单脚本](http://rpg.blue/thread-476318-1-1.html) 中的范例工程所提供窗口皮肤，具体使用版权请查看原工程中说明。

Graphics/System 目录下的 Cursor.png 文件由我自行绘制，允许任意使用。

Graphics/System 目录下的 Window_Tag.png 文件由 [晓寞](http://xiaomoxiaomoxiaomo.lofter.com/) 帮忙绘制，禁止使用在其他任何地方。