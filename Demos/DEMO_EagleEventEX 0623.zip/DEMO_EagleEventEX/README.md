# DEMO - 事件交互扩展

本目录下为 Event System 目录下的插件的范例工程。

## 注意

由于老鹰的懒惰，工程中所使用的插件版本可能并不是最新版，请自己比对。

## 素材来源

Graphics/Pictures 目录下的 LOGO_EAGLE.png 文件由 [葱兔](http://onira.lofter.com/) 帮忙绘制，禁止使用在其他任何地方。

Graphics/System 目录下的 Window_Tag.png 文件由 [晓寞](http://xiaomoxiaomoxiaomo.lofter.com/) 帮忙绘制，禁止使用在其他任何地方。